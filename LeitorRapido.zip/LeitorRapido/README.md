# Leitor Rápido

Aplicativo Android nativo de leitura rápida (RSVP) em Kotlin + Jetpack Compose + Material 3.

## Funcionalidades

- **Aba Ler**: Cole ou digite texto → contagem de palavras em tempo real → leitura RSVP com letra de referência (ORP) centralizada em vermelho.
- Controles: velocidade 60–1200 PPM, play/pause, anterior/próxima, reiniciar, barra de progresso, retomada automática.
- **Aba Livros PDF**: Importação via seletor de documentos, biblioteca local, extração de texto offline (PDFBox), progresso salvo.
- **Aba Resumos**: Geração offline extrativa em 3 níveis (Curto / Equilibrado / Detalhado), salvamento local, copiar e excluir.
- Tema escuro focado em leitura (quase preto + grafite + vermelho vivo).
- 100% offline, sem login, sem servidor.
- Persistência com Room.
- Arquitetura limpa: ViewModels + StateFlow + sealed UI states + Navigation Compose.

## Como abrir e gerar o APK

1. Abra o Android Studio (Hedgehog ou mais recente recomendado).
2. **File → Open** e selecione a pasta `LeitorRapido`.
3. Aguarde o Gradle Sync (pode demorar na primeira vez por causa do PDFBox).
4. Conecte um celular ou use um emulador.
5. Clique em **Run** (▶️) ou gere o APK:
   - **Build → Build Bundle(s) / APK(s) → Build APK(s)**
   - O APK ficará em `app/build/outputs/apk/debug/app-debug.apk`

### Gerar APK de release (assinado)

```bash
./gradlew assembleRelease
```

(Você precisará configurar um keystore em `app/build.gradle.kts` para release.)

## Requisitos

- minSdk 26 (Android 8.0+)
- Kotlin 2.0 / Compose BOM 2024.10
- Internet apenas para baixar as dependências na primeira build (o app em si é offline).

## Observações

- PDFs que são apenas imagens (sem camada de texto) não terão texto extraído — o app avisa o usuário.
- O resumo é **extrativo determinístico** (frequência de palavras + posição das frases). Não usa modelo de IA local para manter o app leve e 100% offline.
- A letra vermelha no RSVP é o Optimal Recognition Point (ORP) e é centralizada com medição real de texto.
