package com.leitorrapido.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.leitorrapido.ui.theme.AccentRed
import com.leitorrapido.ui.theme.TextPrimary
import com.leitorrapido.util.TextUtils

/**
 * Displays a single word with the Optimal Recognition Point (ORP) letter
 * perfectly centered horizontally on the screen and highlighted in red.
 * Uses real text measurement for precise alignment.
 */
@Composable
fun RsvpWordDisplay(
    word: String,
    modifier: Modifier = Modifier,
    textColor: Color = TextPrimary,
    accentColor: Color = AccentRed,
    fontSize: Float = 42f
) {
    val textMeasurer = rememberTextMeasurer()
    val density = LocalDensity.current
    val alpha = remember { Animatable(0.4f) }

    LaunchedEffect(word) {
        alpha.snapTo(0.4f)
        alpha.animateTo(1f, animationSpec = tween(80))
    }

    val style = TextStyle(
        fontSize = fontSize.sp,
        fontWeight = FontWeight.Medium,
        letterSpacing = 0.sp
    )

    val orpIndex = TextUtils.findOrpIndex(word)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        // Custom layout that measures left part, ORP letter and right part,
        // then offsets so the center of the ORP letter sits at the screen center.
        Layout(
            content = {
                // Left of ORP
                if (orpIndex > 0) {
                    Text(
                        text = word.substring(0, orpIndex),
                        style = style,
                        color = textColor,
                        modifier = Modifier.alpha(alpha.value)
                    )
                }
                // ORP letter (red)
                if (word.isNotEmpty() && orpIndex < word.length) {
                    Text(
                        text = word[orpIndex].toString(),
                        style = style.copy(fontWeight = FontWeight.Bold),
                        color = accentColor,
                        modifier = Modifier.alpha(alpha.value)
                    )
                }
                // Right of ORP
                if (orpIndex + 1 < word.length) {
                    Text(
                        text = word.substring(orpIndex + 1),
                        style = style,
                        color = textColor,
                        modifier = Modifier.alpha(alpha.value)
                    )
                }
            },
            measurePolicy = { measurables, constraints ->
                val placeables = measurables.map { it.measure(Constraints()) }
                val leftWidth = if (orpIndex > 0 && placeables.isNotEmpty()) placeables[0].width else 0
                val orpWidth = when {
                    word.isEmpty() -> 0
                    orpIndex == 0 && placeables.isNotEmpty() -> placeables[0].width
                    orpIndex > 0 && placeables.size > 1 -> placeables[1].width
                    else -> 0
                }
                val totalWidth = placeables.sumOf { it.width }
                val height = placeables.maxOfOrNull { it.height } ?: 0

                val layoutWidth = constraints.maxWidth
                // Center of the ORP letter should be at layoutWidth / 2
                val orpCenterOffset = leftWidth + orpWidth / 2
                val startX = (layoutWidth / 2) - orpCenterOffset

                layout(layoutWidth, height) {
                    var x = startX
                    placeables.forEach { placeable ->
                        placeable.placeRelative(x, 0)
                        x += placeable.width
                    }
                }
            }
        )
    }
}
