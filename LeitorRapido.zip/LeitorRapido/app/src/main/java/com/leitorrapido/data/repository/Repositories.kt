package com.leitorrapido.data.repository

import android.content.Context
import android.net.Uri
import com.leitorrapido.data.local.BookDao
import com.leitorrapido.data.local.SummaryDao
import com.leitorrapido.data.local.TextHistoryDao
import com.leitorrapido.data.model.Book
import com.leitorrapido.data.model.Summary
import com.leitorrapido.data.model.SummaryLevel
import com.leitorrapido.data.model.TextHistory
import com.leitorrapido.util.PdfTextExtractor
import com.leitorrapido.util.SummaryGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

class BookRepository(
    private val bookDao: BookDao,
    private val context: Context
) {
    val books: Flow<List<Book>> = bookDao.getAllBooks()

    suspend fun importPdf(uri: Uri, displayName: String): Result<Book> = withContext(Dispatchers.IO) {
        try {
            val pdfDir = File(context.filesDir, "pdfs").apply { mkdirs() }
            val safeName = displayName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            val destFile = File(pdfDir, "${System.currentTimeMillis()}_$safeName")

            context.contentResolver.openInputStream(uri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext Result.failure(Exception("Não foi possível abrir o arquivo"))

            val extraction = PdfTextExtractor.extract(destFile)
            if (extraction.text.isBlank()) {
                destFile.delete()
                return@withContext Result.failure(Exception("Este PDF não contém texto extraível (pode ser apenas imagens)."))
            }

            val book = Book(
                fileName = safeName,
                displayName = displayName.removeSuffix(".pdf"),
                filePath = destFile.absolutePath,
                pageCount = extraction.pageCount,
                wordCount = extraction.wordCount
            )
            val id = bookDao.insert(book)
            Result.success(book.copy(id = id))
        } catch (e: Exception) {
            Result.failure(Exception("Erro ao importar: ${e.message}"))
        }
    }

    suspend fun getBookText(book: Book): String = withContext(Dispatchers.IO) {
        val file = File(book.filePath)
        if (!file.exists()) return@withContext ""
        PdfTextExtractor.extract(file).text
    }

    suspend fun updateProgress(bookId: Long, position: Int, totalWords: Int) {
        val progress = if (totalWords > 0) (position + 1).toFloat() / totalWords else 0f
        bookDao.updateProgress(bookId, position, progress)
    }

    suspend fun deleteBook(book: Book) {
        File(book.filePath).delete()
        bookDao.delete(book)
    }

    suspend fun getBook(id: Long) = bookDao.getBookById(id)
}

class SummaryRepository(private val summaryDao: SummaryDao) {
    val summaries: Flow<List<Summary>> = summaryDao.getAllSummaries()

    suspend fun generateSummary(
        sourceName: String,
        fullText: String,
        level: SummaryLevel,
        pageCount: Int,
        bookId: Long? = null
    ): Summary = withContext(Dispatchers.Default) {
        val content = SummaryGenerator.generate(fullText, level)
        val summary = Summary(
            bookId = bookId,
            sourceName = sourceName,
            level = level,
            content = content,
            pageCountAnalyzed = pageCount,
            isLocalExtractive = true
        )
        val id = summaryDao.insert(summary)
        summary.copy(id = id)
    }

    suspend fun delete(summary: Summary) = summaryDao.delete(summary)
    suspend fun getById(id: Long) = summaryDao.getSummaryById(id)
}

class TextHistoryRepository(private val dao: TextHistoryDao) {
    val history: Flow<List<TextHistory>> = dao.getHistory()

    suspend fun save(title: String, content: String, wordCount: Int, lastPosition: Int = 0): Long {
        return dao.insert(
            TextHistory(
                title = title.ifBlank { "Texto ${System.currentTimeMillis()}" },
                content = content,
                wordCount = wordCount,
                lastPosition = lastPosition
            )
        )
    }

    suspend fun updatePosition(id: Long, position: Int) = dao.updatePosition(id, position)
    suspend fun delete(item: TextHistory) = dao.delete(item)
}
