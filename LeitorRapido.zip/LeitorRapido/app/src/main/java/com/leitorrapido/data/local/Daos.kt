package com.leitorrapido.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.leitorrapido.data.model.Book
import com.leitorrapido.data.model.Summary
import com.leitorrapido.data.model.TextHistory
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {
    @Query("SELECT * FROM books ORDER BY lastOpenedAt DESC")
    fun getAllBooks(): Flow<List<Book>>

    @Query("SELECT * FROM books WHERE id = :id")
    suspend fun getBookById(id: Long): Book?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(book: Book): Long

    @Update
    suspend fun update(book: Book)

    @Delete
    suspend fun delete(book: Book)

    @Query("UPDATE books SET lastPosition = :position, progressPercent = :progress, lastOpenedAt = :time WHERE id = :id")
    suspend fun updateProgress(id: Long, position: Int, progress: Float, time: Long = System.currentTimeMillis())
}

@Dao
interface SummaryDao {
    @Query("SELECT * FROM summaries ORDER BY createdAt DESC")
    fun getAllSummaries(): Flow<List<Summary>>

    @Query("SELECT * FROM summaries WHERE id = :id")
    suspend fun getSummaryById(id: Long): Summary?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(summary: Summary): Long

    @Delete
    suspend fun delete(summary: Summary)
}

@Dao
interface TextHistoryDao {
    @Query("SELECT * FROM text_history ORDER BY lastReadAt DESC LIMIT 50")
    fun getHistory(): Flow<List<TextHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: TextHistory): Long

    @Update
    suspend fun update(item: TextHistory)

    @Delete
    suspend fun delete(item: TextHistory)

    @Query("UPDATE text_history SET lastPosition = :position, lastReadAt = :time WHERE id = :id")
    suspend fun updatePosition(id: Long, position: Int, time: Long = System.currentTimeMillis())
}
