package com.leitorrapido.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.leitorrapido.data.model.Book
import com.leitorrapido.data.model.Summary
import com.leitorrapido.data.model.SummaryLevel
import com.leitorrapido.data.model.UiState
import com.leitorrapido.data.repository.BookRepository
import com.leitorrapido.data.repository.SummaryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SummariesViewModel(
    private val summaryRepository: SummaryRepository,
    private val bookRepository: BookRepository
) : ViewModel() {

    val summaries = summaryRepository.summaries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _generationState = MutableStateFlow<UiState<Summary>>(UiState.Idle)
    val generationState: StateFlow<UiState<Summary>> = _generationState.asStateFlow()

    private val _progressPages = MutableStateFlow(0 to 0)
    val progressPages: StateFlow<Pair<Int, Int>> = _progressPages.asStateFlow()

    fun generateFromBook(book: Book, level: SummaryLevel) {
        viewModelScope.launch {
            _generationState.value = UiState.Loading
            _progressPages.value = 0 to book.pageCount
            try {
                val text = bookRepository.getBookText(book)
                if (text.isBlank()) {
                    _generationState.value = UiState.Error("PDF sem texto extraível.")
                    return@launch
                }
                // Simulate page progress for UX (extraction is fast, but we show feedback)
                for (i in 1..book.pageCount.coerceAtLeast(1)) {
                    _progressPages.value = i to book.pageCount
                    kotlinx.coroutines.delay(30)
                }
                val summary = summaryRepository.generateSummary(
                    sourceName = book.displayName,
                    fullText = text,
                    level = level,
                    pageCount = book.pageCount,
                    bookId = book.id
                )
                _generationState.value = UiState.Success(summary)
            } catch (e: Exception) {
                _generationState.value = UiState.Error(e.message ?: "Erro ao gerar resumo")
            }
        }
    }

    fun clearGenerationState() {
        _generationState.value = UiState.Idle
        _progressPages.value = 0 to 0
    }

    fun deleteSummary(summary: Summary) {
        viewModelScope.launch {
            summaryRepository.delete(summary)
        }
    }

    class Factory(
        private val summaryRepository: SummaryRepository,
        private val bookRepository: BookRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SummariesViewModel(summaryRepository, bookRepository) as T
        }
    }
}
