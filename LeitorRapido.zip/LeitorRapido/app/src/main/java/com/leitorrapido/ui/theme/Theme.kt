package com.leitorrapido.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AccentRed,
    onPrimary = Color.White,
    primaryContainer = AccentRedDim,
    onPrimaryContainer = Color.White,
    secondary = GraphiteLight,
    onSecondary = TextPrimary,
    secondaryContainer = Graphite,
    onSecondaryContainer = TextPrimary,
    tertiary = AccentRed,
    background = AlmostBlack,
    onBackground = TextPrimary,
    surface = Graphite,
    onSurface = TextPrimary,
    surfaceVariant = GraphiteLight,
    onSurfaceVariant = TextSecondary,
    outline = ProgressTrack,
    error = AccentRed,
    onError = Color.White
)

@Composable
fun LeitorRapidoTheme(
    darkTheme: Boolean = true, // Always dark for reading focus
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
