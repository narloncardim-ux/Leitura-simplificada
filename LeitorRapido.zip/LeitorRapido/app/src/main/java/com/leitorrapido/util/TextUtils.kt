package com.leitorrapido.util

object TextUtils {

    /**
     * Splits text into words suitable for RSVP.
     * Keeps punctuation attached to the word for natural reading.
     */
    fun splitIntoWords(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        return text
            .replace(Regex("[\\r\\n]+"), " ")
            .split(Regex("\\s+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }
    }

    fun countWords(text: String): Int = splitIntoWords(text).size

    /**
     * Finds the "ORP" (Optimal Recognition Point) index inside a word.
     * Typically around 1/3 from the left for short words, closer to center for longer ones.
     * This is the letter that should be colored red and centered.
     */
    fun findOrpIndex(word: String): Int {
        val clean = word.filter { it.isLetterOrDigit() }
        if (clean.isEmpty()) return word.length / 2
        return when {
            clean.length <= 1 -> 0
            clean.length <= 5 -> 1
            clean.length <= 9 -> 2
            clean.length <= 13 -> 3
            else -> clean.length / 3
        }.coerceIn(0, word.lastIndex)
    }
}
