package com.leitorrapido.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.leitorrapido.data.model.ReadingState
import com.leitorrapido.data.repository.BookRepository
import com.leitorrapido.data.repository.TextHistoryRepository
import com.leitorrapido.util.TextUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class ReadingViewModel(
    private val textHistoryRepository: TextHistoryRepository,
    private val bookRepository: BookRepository
) : ViewModel() {

    private val _readingState = MutableStateFlow(ReadingState())
    val readingState: StateFlow<ReadingState> = _readingState.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _wordCount = MutableStateFlow(0)
    val wordCount: StateFlow<Int> = _wordCount.asStateFlow()

    private val _isReadingScreen = MutableStateFlow(false)
    val isReadingScreen: StateFlow<Boolean> = _isReadingScreen.asStateFlow()

    private var playJob: Job? = null
    private var currentHistoryId: Long? = null
    private var currentBookId: Long? = null

    fun onTextChange(text: String) {
        _inputText.value = text
        _wordCount.value = TextUtils.countWords(text)
    }

    fun startReadingFromInput(resumePosition: Int = 0) {
        val words = TextUtils.splitIntoWords(_inputText.value)
        if (words.isEmpty()) return

        viewModelScope.launch {
            currentHistoryId = textHistoryRepository.save(
                title = _inputText.value.take(40).replace("\n", " "),
                content = _inputText.value,
                wordCount = words.size,
                lastPosition = resumePosition
            )
            currentBookId = null
        }

        _readingState.value = ReadingState(
            words = words,
            currentIndex = resumePosition.coerceIn(0, words.lastIndex),
            isPlaying = false,
            wpm = _readingState.value.wpm
        )
        _isReadingScreen.value = true
    }

    fun startReadingFromBook(bookId: Long, text: String, resumePosition: Int) {
        val words = TextUtils.splitIntoWords(text)
        if (words.isEmpty()) return
        currentBookId = bookId
        currentHistoryId = null
        _readingState.value = ReadingState(
            words = words,
            currentIndex = resumePosition.coerceIn(0, words.lastIndex.coerceAtLeast(0)),
            isPlaying = false,
            wpm = _readingState.value.wpm
        )
        _isReadingScreen.value = true
    }

    fun togglePlayPause() {
        val state = _readingState.value
        if (state.words.isEmpty()) return
        if (state.isPlaying) {
            pause()
        } else {
            play()
        }
    }

    private fun play() {
        playJob?.cancel()
        _readingState.update { it.copy(isPlaying = true, isFinished = false) }
        playJob = viewModelScope.launch {
            while (isActive) {
                val current = _readingState.value
                if (current.currentIndex >= current.words.lastIndex) {
                    _readingState.update { it.copy(isPlaying = false, isFinished = true) }
                    saveProgress()
                    break
                }
                val delayMs = (60_000L / current.wpm.coerceIn(60, 1200))
                delay(delayMs)
                _readingState.update { s ->
                    if (!s.isPlaying) return@update s
                    s.copy(currentIndex = (s.currentIndex + 1).coerceAtMost(s.words.lastIndex))
                }
            }
        }
    }

    fun pause() {
        playJob?.cancel()
        _readingState.update { it.copy(isPlaying = false) }
        saveProgress()
    }

    fun nextWord() {
        pause()
        _readingState.update { s ->
            if (s.words.isEmpty()) s
            else s.copy(currentIndex = (s.currentIndex + 1).coerceAtMost(s.words.lastIndex))
        }
        saveProgress()
    }

    fun previousWord() {
        pause()
        _readingState.update { s ->
            s.copy(currentIndex = (s.currentIndex - 1).coerceAtLeast(0))
        }
        saveProgress()
    }

    fun restart() {
        pause()
        _readingState.update { it.copy(currentIndex = 0, isFinished = false) }
        saveProgress()
    }

    fun setWpm(wpm: Int) {
        _readingState.update { it.copy(wpm = wpm.coerceIn(60, 1200)) }
    }

    fun exitReading() {
        pause()
        saveProgress()
        _isReadingScreen.value = false
    }

    private fun saveProgress() {
        val state = _readingState.value
        viewModelScope.launch {
            currentHistoryId?.let { id ->
                textHistoryRepository.updatePosition(id, state.currentIndex)
            }
            currentBookId?.let { id ->
                bookRepository.updateProgress(id, state.currentIndex, state.totalWords)
            }
        }
    }

    override fun onCleared() {
        playJob?.cancel()
        super.onCleared()
    }

    class Factory(
        private val textHistoryRepository: TextHistoryRepository,
        private val bookRepository: BookRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ReadingViewModel(textHistoryRepository, bookRepository) as T
        }
    }
}
