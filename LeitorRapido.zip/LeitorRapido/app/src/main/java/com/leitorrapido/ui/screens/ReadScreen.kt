package com.leitorrapido.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.leitorrapido.ui.components.EmptyState
import com.leitorrapido.ui.components.EmptyIcons
import com.leitorrapido.ui.components.ReadingControls
import com.leitorrapido.ui.components.RsvpWordDisplay
import com.leitorrapido.ui.theme.AccentRed
import com.leitorrapido.ui.theme.AlmostBlack
import com.leitorrapido.ui.theme.Graphite
import com.leitorrapido.ui.theme.GraphiteLight
import com.leitorrapido.ui.theme.TextPrimary
import com.leitorrapido.ui.theme.TextSecondary
import com.leitorrapido.viewmodel.ReadingViewModel

@Composable
fun ReadScreen(
    viewModel: ReadingViewModel,
    modifier: Modifier = Modifier
) {
    val isReading by viewModel.isReadingScreen.collectAsState()
    val readingState by viewModel.readingState.collectAsState()
    val inputText by viewModel.inputText.collectAsState()
    val wordCount by viewModel.wordCount.collectAsState()

    if (isReading) {
        ReadingFullscreen(
            state = readingState,
            onPlayPause = viewModel::togglePlayPause,
            onPrevious = viewModel::previousWord,
            onNext = viewModel::nextWord,
            onRestart = viewModel::restart,
            onWpmChange = viewModel::setWpm,
            onExit = viewModel::exitReading
        )
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(AlmostBlack)
                .padding(16.dp)
        ) {
            Text(
                text = "Cole ou digite o texto",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary
            )
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = inputText,
                onValueChange = viewModel::onTextChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                placeholder = {
                    Text("Cole ou digite o texto aqui…", color = TextSecondary)
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AccentRed,
                    unfocusedBorderColor = GraphiteLight,
                    focusedContainerColor = Graphite,
                    unfocusedContainerColor = Graphite,
                    cursorColor = AccentRed,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                maxLines = 20
            )

            Spacer(Modifier.height(12.dp))

            Text(
                text = "$wordCount palavras",
                style = MaterialTheme.typography.labelLarge,
                color = TextSecondary
            )

            Spacer(Modifier.height(12.dp))

            Button(
                onClick = { viewModel.startReadingFromInput() },
                enabled = wordCount > 0,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentRed,
                    contentColor = TextPrimary,
                    disabledContainerColor = GraphiteLight
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Iniciar leitura RSVP", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
private fun ReadingFullscreen(
    state: com.leitorrapido.data.model.ReadingState,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onRestart: () -> Unit,
    onWpmChange: (Int) -> Unit,
    onExit: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AlmostBlack)
    ) {
        // Top bar with exit
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Button(
                onClick = onExit,
                colors = ButtonDefaults.textButtonColors(contentColor = TextSecondary)
            ) {
                Text("← Voltar")
            }
        }

        // Central word display
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            if (state.words.isEmpty()) {
                EmptyState(icon = EmptyIcons.Text, message = "Nenhuma palavra para ler.")
            } else {
                RsvpWordDisplay(word = state.currentWord)
            }
        }

        // Controls at bottom
        ReadingControls(
            state = state,
            onPlayPause = onPlayPause,
            onPrevious = onPrevious,
            onNext = onNext,
            onRestart = onRestart,
            onWpmChange = onWpmChange
        )
    }
}
