package com.leitorrapido.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Summarize
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.leitorrapido.ui.screens.BooksScreen
import com.leitorrapido.ui.screens.ReadScreen
import com.leitorrapido.ui.screens.SummariesScreen
import com.leitorrapido.ui.theme.AccentRed
import com.leitorrapido.ui.theme.AlmostBlack
import com.leitorrapido.ui.theme.Graphite
import com.leitorrapido.ui.theme.TextPrimary
import com.leitorrapido.ui.theme.TextSecondary
import com.leitorrapido.viewmodel.BooksViewModel
import com.leitorrapido.viewmodel.ReadingViewModel
import com.leitorrapido.viewmodel.SummariesViewModel

sealed class Screen(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    data object Read : Screen("read", "Ler", Icons.Filled.MenuBook, Icons.Outlined.MenuBook)
    data object Books : Screen("books", "Livros PDF", Icons.Filled.AutoStories, Icons.Outlined.AutoStories)
    data object Summaries : Screen("summaries", "Resumos", Icons.Filled.Summarize, Icons.Outlined.Summarize)
}

@Composable
fun AppNavigation(
    readingViewModel: ReadingViewModel,
    booksViewModel: BooksViewModel,
    summariesViewModel: SummariesViewModel
) {
    val navController = rememberNavController()
    val items = listOf(Screen.Read, Screen.Books, Screen.Summaries)

    Scaffold(
        containerColor = AlmostBlack,
        bottomBar = {
            NavigationBar(containerColor = Graphite) {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                items.forEach { screen ->
                    val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        icon = {
                            Icon(
                                imageVector = if (selected) screen.selectedIcon else screen.unselectedIcon,
                                contentDescription = screen.label
                            )
                        },
                        label = { Text(screen.label) },
                        selected = selected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AccentRed,
                            selectedTextColor = AccentRed,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = AccentRed.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Read.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Read.route) {
                ReadScreen(viewModel = readingViewModel)
            }
            composable(Screen.Books.route) {
                BooksScreen(
                    booksViewModel = booksViewModel,
                    readingViewModel = readingViewModel
                )
            }
            composable(Screen.Summaries.route) {
                SummariesScreen(
                    summariesViewModel = summariesViewModel,
                    booksViewModel = booksViewModel
                )
            }
        }
    }
}
