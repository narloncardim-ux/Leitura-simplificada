package com.leitorrapido.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.leitorrapido.data.model.Book
import com.leitorrapido.data.model.Summary
import com.leitorrapido.data.model.SummaryLevel
import com.leitorrapido.data.model.UiState
import com.leitorrapido.ui.components.EmptyState
import com.leitorrapido.ui.components.EmptyIcons
import com.leitorrapido.ui.theme.AccentRed
import com.leitorrapido.ui.theme.AlmostBlack
import com.leitorrapido.ui.theme.Graphite
import com.leitorrapido.ui.theme.TextPrimary
import com.leitorrapido.ui.theme.TextSecondary
import com.leitorrapido.viewmodel.BooksViewModel
import com.leitorrapido.viewmodel.SummariesViewModel

@Composable
fun SummariesScreen(
    summariesViewModel: SummariesViewModel,
    booksViewModel: BooksViewModel,
    modifier: Modifier = Modifier
) {
    val summaries by summariesViewModel.summaries.collectAsState()
    val books by booksViewModel.books.collectAsState()
    val generationState by summariesViewModel.generationState.collectAsState()
    val progress by summariesViewModel.progressPages.collectAsState()

    var showBookPicker by remember { mutableStateOf(false) }
    var selectedBook by remember { mutableStateOf<Book?>(null) }
    var selectedLevel by remember { mutableStateOf(SummaryLevel.BALANCED) }
    var viewingSummary by remember { mutableStateOf<Summary?>(null) }

    val context = LocalContext.current

    LaunchedEffect(generationState) {
        if (generationState is UiState.Success) {
            showBookPicker = false
            selectedBook = null
            summariesViewModel.clearGenerationState()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AlmostBlack)
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Resumos",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Button(
                    onClick = { showBookPicker = true },
                    enabled = books.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Novo resumo")
                }
            }

            if (generationState is UiState.Loading) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = AccentRed)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Processando… ${progress.first} / ${progress.second} páginas",
                        color = TextSecondary
                    )
                    Text(
                        "Resumo gerado localmente (método extrativo)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }

            if (summaries.isEmpty() && generationState !is UiState.Loading) {
                EmptyState(
                    icon = EmptyIcons.Summaries,
                    message = "Nenhum resumo gerado.\nSelecione um PDF para criar um resumo local."
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(summaries, key = { it.id }) { summary ->
                        SummaryCard(
                            summary = summary,
                            onOpen = { viewingSummary = summary },
                            onCopy = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Resumo", summary.content))
                            },
                            onDelete = { summariesViewModel.deleteSummary(summary) }
                        )
                    }
                }
            }
        }
    }

    // Book + level picker dialog
    if (showBookPicker) {
        AlertDialog(
            onDismissRequest = { showBookPicker = false },
            title = { Text("Gerar resumo", color = TextPrimary) },
            text = {
                Column {
                    Text("Escolha o livro:", color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    books.forEach { book ->
                        Text(
                            text = book.displayName,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedBook = book }
                                .padding(8.dp)
                                .background(
                                    if (selectedBook?.id == book.id) AccentRed.copy(alpha = 0.2f)
                                    else Graphite,
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(10.dp),
                            color = TextPrimary
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Nível:", color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            SummaryLevel.SHORT to "Curto",
                            SummaryLevel.BALANCED to "Equilibrado",
                            SummaryLevel.DETAILED to "Detalhado"
                        ).forEach { (level, label) ->
                            Button(
                                onClick = { selectedLevel = level },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedLevel == level) AccentRed else Graphite
                                )
                            ) {
                                Text(label)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        selectedBook?.let {
                            summariesViewModel.generateFromBook(it, selectedLevel)
                        }
                    },
                    enabled = selectedBook != null
                ) {
                    Text("Gerar", color = AccentRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBookPicker = false }) {
                    Text("Cancelar", color = TextSecondary)
                }
            },
            containerColor = Graphite
        )
    }

    // View summary dialog
    viewingSummary?.let { summary ->
        AlertDialog(
            onDismissRequest = { viewingSummary = null },
            title = {
                Text(
                    "${summary.sourceName} • ${summary.level.name.lowercase().replaceFirstChar { it.uppercase() }}",
                    color = TextPrimary
                )
            },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    if (summary.isLocalExtractive) {
                        Text(
                            "Resumo gerado localmente (método extrativo).",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    Text(summary.content, color = TextPrimary)
                }
            },
            confirmButton = {
                TextButton(onClick = { viewingSummary = null }) {
                    Text("Fechar", color = AccentRed)
                }
            },
            containerColor = Graphite
        )
    }
}

@Composable
private fun SummaryCard(
    summary: Summary,
    onOpen: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = Graphite),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Summarize, contentDescription = null, tint = AccentRed, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(summary.sourceName, style = MaterialTheme.typography.titleMedium, color = TextPrimary, maxLines = 1)
                Text(
                    "${summary.level.name.lowercase().replaceFirstChar { it.uppercase() }} • ${summary.pageCountAnalyzed} páginas",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
            }
            IconButton(onClick = onCopy) {
                Icon(Icons.Default.ContentCopy, contentDescription = "Copiar", tint = TextSecondary)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Excluir", tint = TextSecondary)
            }
        }
    }
}
