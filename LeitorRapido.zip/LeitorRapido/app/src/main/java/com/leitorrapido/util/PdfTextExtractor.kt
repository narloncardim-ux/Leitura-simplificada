package com.leitorrapido.util

import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File

data class PdfExtractionResult(
    val text: String,
    val pageCount: Int,
    val wordCount: Int
)

object PdfTextExtractor {

    fun extract(file: File): PdfExtractionResult {
        if (!file.exists() || file.length() == 0L) {
            return PdfExtractionResult("", 0, 0)
        }
        return try {
            PDDocument.load(file).use { document ->
                val stripper = PDFTextStripper().apply {
                    sortByPosition = true
                }
                val text = stripper.getText(document).trim()
                val wordCount = text.split(Regex("\\s+")).count { it.isNotBlank() }
                PdfExtractionResult(
                    text = text,
                    pageCount = document.numberOfPages,
                    wordCount = wordCount
                )
            }
        } catch (e: Exception) {
            PdfExtractionResult("", 0, 0)
        }
    }

    fun extractWithProgress(
        file: File,
        onPage: (current: Int, total: Int) -> Unit
    ): PdfExtractionResult {
        if (!file.exists()) return PdfExtractionResult("", 0, 0)
        return try {
            PDDocument.load(file).use { document ->
                val total = document.numberOfPages
                val stripper = PDFTextStripper().apply { sortByPosition = true }
                val sb = StringBuilder()
                for (page in 1..total) {
                    stripper.startPage = page
                    stripper.endPage = page
                    sb.append(stripper.getText(document)).append("\n")
                    onPage(page, total)
                }
                val text = sb.toString().trim()
                val wordCount = text.split(Regex("\\s+")).count { it.isNotBlank() }
                PdfExtractionResult(text, total, wordCount)
            }
        } catch (e: Exception) {
            PdfExtractionResult("", 0, 0)
        }
    }
}
