package com.leitorrapido.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.leitorrapido.data.model.Book
import com.leitorrapido.data.model.Summary
import com.leitorrapido.data.model.SummaryLevel
import com.leitorrapido.data.model.TextHistory

class Converters {
    @TypeConverter
    fun fromSummaryLevel(value: SummaryLevel): String = value.name

    @TypeConverter
    fun toSummaryLevel(value: String): SummaryLevel = SummaryLevel.valueOf(value)
}

@Database(
    entities = [Book::class, Summary::class, TextHistory::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun bookDao(): BookDao
    abstract fun summaryDao(): SummaryDao
    abstract fun textHistoryDao(): TextHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "leitor_rapido.db"
                ).fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
