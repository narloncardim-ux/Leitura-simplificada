package com.leitorrapido.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class Book(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val displayName: String,
    val filePath: String,           // Internal storage path
    val pageCount: Int = 0,
    val wordCount: Int = 0,
    val lastPosition: Int = 0,      // Word index
    val progressPercent: Float = 0f,
    val importedAt: Long = System.currentTimeMillis(),
    val lastOpenedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "summaries")
data class Summary(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long? = null,
    val sourceName: String,
    val level: SummaryLevel,
    val content: String,
    val pageCountAnalyzed: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val isLocalExtractive: Boolean = true
)

enum class SummaryLevel {
    SHORT, BALANCED, DETAILED
}

@Entity(tableName = "text_history")
data class TextHistory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val wordCount: Int,
    val lastPosition: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val lastReadAt: Long = System.currentTimeMillis()
)

sealed class UiState<out T> {
    data object Idle : UiState<Nothing>()
    data object Loading : UiState<Nothing>()
    data class Success<T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
}

data class ReadingState(
    val words: List<String> = emptyList(),
    val currentIndex: Int = 0,
    val isPlaying: Boolean = false,
    val wpm: Int = 300,
    val isFinished: Boolean = false
) {
    val currentWord: String get() = words.getOrElse(currentIndex) { "" }
    val progress: Float get() = if (words.isEmpty()) 0f else (currentIndex + 1).toFloat() / words.size
    val totalWords: Int get() = words.size
}
