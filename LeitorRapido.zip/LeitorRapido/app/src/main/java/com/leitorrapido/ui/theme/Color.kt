package com.leitorrapido.ui.theme

import androidx.compose.ui.graphics.Color

// Dark theme focused on reading comfort
val AlmostBlack = Color(0xFF0A0A0A)
val Graphite = Color(0xFF1C1C1E)
val GraphiteLight = Color(0xFF2C2C2E)
val GraphiteDark = Color(0xFF121212)
val TextPrimary = Color(0xFFE8E8E8)
val TextSecondary = Color(0xFFA0A0A0)
val AccentRed = Color(0xFFFF2D2D)          // Vermelho vivo
val AccentRedDim = Color(0xFFCC2222)
val ProgressTrack = Color(0xFF3A3A3C)
val SuccessGreen = Color(0xFF30D158)
val WarningOrange = Color(0xFFFF9F0A)
