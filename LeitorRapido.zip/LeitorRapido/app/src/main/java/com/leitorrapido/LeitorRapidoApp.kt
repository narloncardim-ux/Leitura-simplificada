package com.leitorrapido

import android.app.Application
import com.leitorrapido.data.local.AppDatabase
import com.leitorrapido.data.repository.BookRepository
import com.leitorrapido.data.repository.SummaryRepository
import com.leitorrapido.data.repository.TextHistoryRepository
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class LeitorRapidoApp : Application() {
    val database by lazy { AppDatabase.getInstance(this) }
    val bookRepository by lazy { BookRepository(database.bookDao(), this) }
    val summaryRepository by lazy { SummaryRepository(database.summaryDao()) }
    val textHistoryRepository by lazy { TextHistoryRepository(database.textHistoryDao()) }

    override fun onCreate() {
        super.onCreate()
        // Initialize PDFBox for offline text extraction
        PDFBoxResourceLoader.init(applicationContext)
    }
}
