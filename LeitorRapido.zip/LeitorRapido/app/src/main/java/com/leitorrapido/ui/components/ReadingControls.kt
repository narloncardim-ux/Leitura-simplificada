package com.leitorrapido.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.leitorrapido.data.model.ReadingState
import com.leitorrapido.ui.theme.AccentRed
import com.leitorrapido.ui.theme.GraphiteLight
import com.leitorrapido.ui.theme.ProgressTrack
import com.leitorrapido.ui.theme.TextPrimary
import com.leitorrapido.ui.theme.TextSecondary

@Composable
fun ReadingControls(
    state: ReadingState,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onRestart: () -> Unit,
    onWpmChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Progress + counters
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "${state.currentIndex + 1} / ${state.totalWords}",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
            )
            Text(
                text = "${state.wpm} PPM",
                style = MaterialTheme.typography.labelMedium,
                color = AccentRed
            )
        }

        Spacer(Modifier.height(6.dp))

        LinearProgressIndicator(
            progress = { state.progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp),
            color = AccentRed,
            trackColor = ProgressTrack,
        )

        Spacer(Modifier.height(16.dp))

        // Main transport controls
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            IconButton(
                onClick = onRestart,
                modifier = Modifier.semantics { contentDescription = "Reiniciar leitura" }
            ) {
                Icon(Icons.Default.Replay, contentDescription = null, tint = TextSecondary)
            }

            Spacer(Modifier.width(8.dp))

            IconButton(
                onClick = onPrevious,
                modifier = Modifier.semantics { contentDescription = "Palavra anterior" }
            ) {
                Icon(Icons.Default.SkipPrevious, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(32.dp))
            }

            Spacer(Modifier.width(12.dp))

            val playColor by animateColorAsState(
                targetValue = if (state.isPlaying) AccentRed else TextPrimary,
                label = "playColor"
            )
            IconButton(
                onClick = onPlayPause,
                modifier = Modifier
                    .size(64.dp)
                    .semantics { contentDescription = "Reproduzir ou pausar" }
            ) {
                Icon(
                    imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = playColor,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(Modifier.width(12.dp))

            IconButton(
                onClick = onNext,
                modifier = Modifier.semantics { contentDescription = "Próxima palavra" }
            ) {
                Icon(Icons.Default.SkipNext, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(32.dp))
            }

            Spacer(Modifier.width(8.dp))

            // Placeholder for symmetry
            Spacer(Modifier.size(48.dp))
        }

        Spacer(Modifier.height(12.dp))

        // Speed slider
        Text(
            text = "Velocidade",
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary
        )
        Slider(
            value = state.wpm.toFloat(),
            onValueChange = { onWpmChange(it.toInt()) },
            valueRange = 60f..1200f,
            steps = 22,
            modifier = Modifier
                .fillMaxWidth()
                .semantics { contentDescription = "Ajustar velocidade de ${state.wpm} palavras por minuto" },
            colors = SliderDefaults.colors(
                thumbColor = AccentRed,
                activeTrackColor = AccentRed,
                inactiveTrackColor = GraphiteLight
            )
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("60", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("1200", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
    }
}
