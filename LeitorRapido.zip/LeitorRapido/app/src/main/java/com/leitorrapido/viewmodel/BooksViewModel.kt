package com.leitorrapido.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.leitorrapido.data.model.Book
import com.leitorrapido.data.model.UiState
import com.leitorrapido.data.repository.BookRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BooksViewModel(
    private val bookRepository: BookRepository
) : ViewModel() {

    val books = bookRepository.books
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _importState = MutableStateFlow<UiState<Book>>(UiState.Idle)
    val importState: StateFlow<UiState<Book>> = _importState.asStateFlow()

    private val _selectedBookText = MutableStateFlow<String?>(null)
    val selectedBookText: StateFlow<String?> = _selectedBookText.asStateFlow()

    fun importPdf(uri: Uri, displayName: String) {
        viewModelScope.launch {
            _importState.value = UiState.Loading
            val result = bookRepository.importPdf(uri, displayName)
            _importState.value = result.fold(
                onSuccess = { UiState.Success(it) },
                onFailure = { UiState.Error(it.message ?: "Erro desconhecido") }
            )
        }
    }

    fun clearImportState() {
        _importState.value = UiState.Idle
    }

    fun loadBookText(book: Book, onReady: (String) -> Unit) {
        viewModelScope.launch {
            val text = bookRepository.getBookText(book)
            _selectedBookText.value = text
            onReady(text)
        }
    }

    fun deleteBook(book: Book) {
        viewModelScope.launch {
            bookRepository.deleteBook(book)
        }
    }

    class Factory(private val bookRepository: BookRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return BooksViewModel(bookRepository) as T
        }
    }
}
