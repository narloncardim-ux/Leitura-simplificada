package com.leitorrapido

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.leitorrapido.ui.navigation.AppNavigation
import com.leitorrapido.ui.theme.AlmostBlack
import com.leitorrapido.ui.theme.LeitorRapidoTheme
import com.leitorrapido.viewmodel.BooksViewModel
import com.leitorrapido.viewmodel.ReadingViewModel
import com.leitorrapido.viewmodel.SummariesViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as LeitorRapidoApp

        setContent {
            LeitorRapidoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = AlmostBlack
                ) {
                    val readingViewModel: ReadingViewModel = viewModel(
                        factory = ReadingViewModel.Factory(
                            app.textHistoryRepository,
                            app.bookRepository
                        )
                    )
                    val booksViewModel: BooksViewModel = viewModel(
                        factory = BooksViewModel.Factory(app.bookRepository)
                    )
                    val summariesViewModel: SummariesViewModel = viewModel(
                        factory = SummariesViewModel.Factory(
                            app.summaryRepository,
                            app.bookRepository
                        )
                    )

                    AppNavigation(
                        readingViewModel = readingViewModel,
                        booksViewModel = booksViewModel,
                        summariesViewModel = summariesViewModel
                    )
                }
            }
        }
    }
}
