package com.leitorrapido.util

import com.leitorrapido.data.model.SummaryLevel
import kotlin.math.min

/**
 * Deterministic extractive summarizer (offline, no ML model required).
 * Ranks sentences by word frequency and position, then selects top sentences.
 */
object SummaryGenerator {

    fun generate(fullText: String, level: SummaryLevel): String {
        if (fullText.isBlank()) return "Nenhum texto disponível para resumir."

        val sentences = splitSentences(fullText)
        if (sentences.isEmpty()) return fullText.take(500)

        val targetCount = when (level) {
            SummaryLevel.SHORT -> maxOf(2, (sentences.size * 0.08).toInt())
            SummaryLevel.BALANCED -> maxOf(4, (sentences.size * 0.18).toInt())
            SummaryLevel.DETAILED -> maxOf(6, (sentences.size * 0.30).toInt())
        }.coerceAtMost(sentences.size)

        val wordFreq = buildWordFrequency(fullText)
        val scored = sentences.mapIndexed { index, sentence ->
            val score = scoreSentence(sentence, wordFreq, index, sentences.size)
            ScoredSentence(index, sentence, score)
        }.sortedByDescending { it.score }

        val selected = scored.take(targetCount)
            .sortedBy { it.originalIndex }
            .map { it.sentence }

        return selected.joinToString(" ")
    }

    private data class ScoredSentence(val originalIndex: Int, val sentence: String, val score: Double)

    private fun splitSentences(text: String): List<String> {
        return text
            .replace(Regex("\\s+"), " ")
            .split(Regex("(?<=[.!?])\\s+"))
            .map { it.trim() }
            .filter { it.length > 20 } // ignore very short fragments
    }

    private fun buildWordFrequency(text: String): Map<String, Int> {
        val stopWords = setOf(
            "a", "o", "e", "de", "do", "da", "em", "um", "uma", "os", "as", "para", "com",
            "não", "no", "na", "por", "mais", "se", "que", "como", "mas", "foi", "ao", "ele",
            "das", "tem", "à", "seu", "sua", "ou", "ser", "quando", "muito", "há", "nos", "já",
            "está", "eu", "também", "só", "pelo", "pela", "até", "isso", "ela", "entre", "era",
            "depois", "sem", "mesmo", "aos", "ter", "seus", "suas", "numa", "pelos", "pelas",
            "esse", "eles", "essas", "esses", "pelas", "este", "esta", "estão", "você", "the",
            "and", "of", "to", "in", "is", "it", "that", "for", "on", "with", "as", "be", "at"
        )
        return text.lowercase()
            .split(Regex("[\\s\\p{Punct}]+"))
            .filter { it.length > 2 && it !in stopWords }
            .groupingBy { it }
            .eachCount()
    }

    private fun scoreSentence(
        sentence: String,
        freq: Map<String, Int>,
        position: Int,
        total: Int
    ): Double {
        val words = sentence.lowercase().split(Regex("[\\s\\p{Punct}]+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return 0.0

        val contentScore = words.sumOf { freq[it] ?: 0 }.toDouble() / words.size
        // Slight boost for sentences near the beginning (common in extractive summaries)
        val positionBoost = 1.0 + (1.0 - position.toDouble() / total) * 0.25
        val lengthPenalty = if (words.size < 5 || words.size > 40) 0.7 else 1.0

        return contentScore * positionBoost * lengthPenalty
    }
}
