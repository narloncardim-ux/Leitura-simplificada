package com.leitorrapido.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.leitorrapido.data.model.Book
import com.leitorrapido.data.model.UiState
import com.leitorrapido.ui.components.EmptyState
import com.leitorrapido.ui.components.EmptyIcons
import com.leitorrapido.ui.theme.AccentRed
import com.leitorrapido.ui.theme.AlmostBlack
import com.leitorrapido.ui.theme.Graphite
import com.leitorrapido.ui.theme.GraphiteLight
import com.leitorrapido.ui.theme.ProgressTrack
import com.leitorrapido.ui.theme.TextPrimary
import com.leitorrapido.ui.theme.TextSecondary
import com.leitorrapido.viewmodel.BooksViewModel
import com.leitorrapido.viewmodel.ReadingViewModel

@Composable
fun BooksScreen(
    booksViewModel: BooksViewModel,
    readingViewModel: ReadingViewModel,
    modifier: Modifier = Modifier
) {
    val books by booksViewModel.books.collectAsState()
    val importState by booksViewModel.importState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    val pdfPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val name = it.lastPathSegment?.substringAfterLast('/') ?: "documento.pdf"
            booksViewModel.importPdf(it, name)
        }
    }

    LaunchedEffect(importState) {
        when (val state = importState) {
            is UiState.Success -> {
                snackbarHostState.showSnackbar("Livro importado: ${state.data.displayName}")
                booksViewModel.clearImportState()
            }
            is UiState.Error -> {
                snackbarHostState.showSnackbar(state.message)
                booksViewModel.clearImportState()
            }
            else -> {}
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AlmostBlack)
    ) {
        Column(Modifier.fillMaxSize()) {
            // Header + import button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Biblioteca",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Button(
                    onClick = { pdfPicker.launch(arrayOf("application/pdf")) },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Importar PDF")
                }
            }

            if (importState is UiState.Loading) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = AccentRed)
                    Spacer(Modifier.height(12.dp))
                    Text("Importando e extraindo texto…", color = TextSecondary)
                }
            }

            if (books.isEmpty() && importState !is UiState.Loading) {
                EmptyState(
                    icon = EmptyIcons.Books,
                    message = "Nenhum livro ainda.\nToque em Importar PDF para começar."
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(books, key = { it.id }) { book ->
                        BookCard(
                            book = book,
                            onOpen = {
                                booksViewModel.loadBookText(book) { text ->
                                    readingViewModel.startReadingFromBook(
                                        bookId = book.id,
                                        text = text,
                                        resumePosition = book.lastPosition
                                    )
                                }
                            },
                            onDelete = { booksViewModel.deleteBook(book) }
                        )
                    }
                }
            }
        }
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun BookCard(
    book: Book,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = Graphite),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.PictureAsPdf,
                contentDescription = null,
                tint = AccentRed,
                modifier = Modifier.size(36.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = book.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    maxLines = 1
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "${book.pageCount} páginas • ${book.wordCount} palavras",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                if (book.progressPercent > 0f) {
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { book.progressPercent },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp),
                        color = AccentRed,
                        trackColor = ProgressTrack
                    )
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Excluir", tint = TextSecondary)
            }
        }
    }
}
